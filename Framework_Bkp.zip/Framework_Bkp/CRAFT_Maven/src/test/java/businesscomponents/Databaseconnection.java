package businesscomponents;
import org.testng.annotations.AfterClass;
import com.cognizant.craft.ReusableLibrary;
import com.cognizant.craft.ScriptHelper;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.sql.*;


public class Databaseconnection extends ReusableLibrary {

	
	
	   public Databaseconnection(ScriptHelper scriptHelper) {
		super(scriptHelper);
		// TODO Auto-generated constructor stub
	}

	   private Connection connection;
	   private static Statement statement;
	   private static ResultSet rs;
	   

	    @BeforeClass
	    public void setUp() {
	            String databaseURL = "jdbc:oracle:thin:@ora-ris-rist.7-11.com:1521:rist";
	            String user = "risbatch";
	            String password = "workit_3";
	            connection = null;
	            try {
	                Class.forName("oracle.jdbc.OracleDriver");
	                System.out.println("Connecting to Database...");
	                connection = DriverManager.getConnection(databaseURL, user, password);
	                if (connection != null) {
	                    System.out.println("Connected to the Database...");
	                }
	            } catch (SQLException ex) {
	               ex.printStackTrace();
	            }
	            catch (ClassNotFoundException ex) {
	               ex.printStackTrace();
	            }
	    }

	    @Test
	    public void getTableData() {
	        try {
	            String query = "select * from ALL_TABLE";
	            statement = connection.createStatement();
	            rs = statement.executeQuery(query);

	            while(rs.next()){
	               
	                String tab_name= rs.getString("Table_name");
	                
	                System.out.println("table name is"+"\t"+tab_name);
	            }
	        } catch (SQLException ex) {
	           ex.printStackTrace();
	        }
	    }

	    @AfterClass
	    public void Shutdown() {
	      if (connection != null) {
	                try {
	                    System.out.println("Closing Database Connection...");
	                    connection.close();
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                }
	            }
	      }
}
