package com.cognizant.framework;

public enum ErrorTypes {	
	AutomationFramework_Issue,
	ElementIdentification_Issue,
	AutomationTool_Issue,
	Product_Issue,
	Java_Issue,
	Others
}
